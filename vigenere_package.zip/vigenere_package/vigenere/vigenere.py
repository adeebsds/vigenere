# Write or paste your Vigenère cipher functions here.
def vigencrypt_v3(message, key):
    if not isinstance(message, str) or not isinstance(key, str):
        raise ValueError("Both message and key must be strings.")
    if not key:
        raise ValueError("Key must not be empty.")

    encrypted_message = []
    key = key.upper()
    key_index = 0

    for char in message:
        if char.isalpha():
            shift = ord(key[key_index]) - ord('A')
            if char.islower():
                encrypted_message.append(chr((ord(char) - ord('a') + shift) % 26 + ord('a')))
            else:
                encrypted_message.append(chr((ord(char) - ord('A') + shift) % 26 + ord('A')))
            key_index = (key_index + 1) % len(key)
        else:
            encrypted_message.append(char)

    return ''.join(encrypted_message)


def vigdecrypt_v3(encrypted_message, key):
    if not isinstance(encrypted_message, str) or not isinstance(key, str):
        raise ValueError("Both encrypted_message and key must be strings.")
    if not key:
        raise ValueError("Key must not be empty.")

    decrypted_message = []
    key = key.upper()
    key_index = 0

    for char in encrypted_message:
        if char.isalpha():
            shift = ord(key[key_index]) - ord('A')
            if char.islower():
                decrypted_message.append(chr((ord(char) - ord('a') - shift) % 26 + ord('a')))
            else:
                decrypted_message.append(chr((ord(char) - ord('A') - shift) % 26 + ord('A')))
            key_index = (key_index + 1) % len(key)
        else:
            decrypted_message.append(char)

    return ''.join(decrypted_message)

# Function to find the decryption key and message
def find_key_and_message(encrypted_message, capitals):
    for capital in capitals:
        decrypted_message = vigdecrypt_v3(encrypted_message, capital)
        if "discover" in decrypted_message.lower():
            return capital, decrypted_message
    return None, None
